module.exports.config = {
  name: "adm",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Tùng",
  description: "Xem thông tin adminbot",
  commandCategory: "system",
  usages: "",
  cooldowns: 10,
  dependencies: {
    "request":"",
    "fs-extra":"",
    "axios":""
  }
};

module.exports.run = async({api,event,args,client,Users,Threads,__GLOBAL,Currencies}) => {
const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
  var link = [
"https://i.imgur.com/FKShPO8.jpeg","https://i.imgur.com/iBVEh2T.jpeg","https://i.imgur.com/9zTA1TU.jpeg",
  ];
  var callback = () => api.sendMessage({body:`ABOUT ADMIN 
  🚲 Tên: Thanh Tùng 
  🚲 Sinh ngày: 29-05-2005
  🚲 Mối quan hệ: Độc Thân
  🚲 Quê quán: Thanh Hóa
  🚲 Nơi ở: Quảng Ninh
  🚲 Facebook: https://www.facebook.com/hakuuzies`,attachment: fs.createReadStream(__dirname + "/cache/5.jpg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/5.jpg")); 
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/5.jpg")).on("close",() => callback());
   };